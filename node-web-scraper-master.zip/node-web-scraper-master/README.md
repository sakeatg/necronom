node-web-scraper
================

Simple web scraper to get a movie name, release year and community rating from IMDB.
